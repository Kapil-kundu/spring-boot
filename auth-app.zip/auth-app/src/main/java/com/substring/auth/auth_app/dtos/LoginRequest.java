package com.substring.auth.auth_app.dtos;

public record LoginRequest(
        String email,
        String password
) {

}
