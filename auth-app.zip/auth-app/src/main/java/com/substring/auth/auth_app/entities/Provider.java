package com.substring.auth.auth_app.entities;

public enum Provider {
        LOCAL, GOOGLE, GITHUB, FACEBOOK
}
