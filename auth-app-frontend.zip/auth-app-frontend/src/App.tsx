
import './App.css'
import FuturisticAuthHome from './components/home/FuturisticAuthHome';
import { Button } from './components/ui/button';
import { Calendar } from './components/ui/calendar';
function App() {
  return (
    <div>
        <FuturisticAuthHome />
    </div>
  )
}

export default App
